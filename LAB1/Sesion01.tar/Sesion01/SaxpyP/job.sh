#!/bin/bash

### Directivas para el gestor de colas
#SBATCH --job-name=sAXPYp
#SBATCH -D .
#SBATCH --output=submit-sAXPYp.o%j
#SBATCH --error=submit-sAXPYp.e%j
#SBATCH -A cuda
#SBATCH -p cuda
#SBATCH --gres=gpu:1

export PATH=/Soft/cuda/12.0.1/bin:$PATH

./SaxpyP.exe  

#echo "PRINT GPU SUMMARY nsys nvprof --print-gpu-summary"
#echo "===================================================================="
#nsys nvprof --print-gpu-summary ./SaxpyP.exe
#echo "===================================================================="

#echo "PRINT GPU SUMMARY nsys nvprof --print-gpu-trace"
#echo "===================================================================="
#nsys nvprof --print-gpu-trace ./SaxpyP.exe
#echo "===================================================================="


