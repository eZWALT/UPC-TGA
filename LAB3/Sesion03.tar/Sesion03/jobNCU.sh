#!/bin/bash

### Directivas para el gestor de colas
#SBATCH --job-name=REDUCTOR
#SBATCH -D .
#SBATCH --output=submit-REDUCTOR.sh.o%j
#SBATCH --error=submit-REDUCTOR.sh.e%j
#SBATCH -A cuda
#SBATCH -p cuda
#SBATCH --gres=gpu:4

export PATH=/Soft/cuda/12.0.1/bin:$PATH




for KK in 01 02 03 04 05 06 07 08
do
  echo "Running kernel${KK} //////////////////////////////////////////////////////////////////////////"
  ./kernel${KK}.exe
  echo "Running kernel${KK} \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"
  ncu --set full ./kernel${KK}.exe
  echo "=============================================================================================="
done



