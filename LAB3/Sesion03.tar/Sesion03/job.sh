#!/bin/bash

### Directivas para el gestor de colas
#SBATCH --job-name=REDUCTOR
#SBATCH -D .
#SBATCH --output=submit-REDUCTOR.sh.o%j
#SBATCH --error=submit-REDUCTOR.sh.e%j
#SBATCH -A cuda
#SBATCH -p cuda
#SBATCH --gres=gpu:4

export PATH=/Soft/cuda/12.0.1/bin:$PATH



./kernel01.exe
#./kernel02.exe
#./kernel03.exe
#./kernel04.exe
#./kernel05.exe
#./kernel06.exe
#./kernel07.exe

