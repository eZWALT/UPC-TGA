#!/bin/bash

### Directivas para el gestor de colas
#SBATCH --job-name=ProdMbyM
#SBATCH -D .
#SBATCH --output=submit-ProdMbyM.o%j
#SBATCH --error=submit-ProdMbyM.e%j
#SBATCH -A cuda
#SBATCH -p cuda
#SBATCH --gres=gpu:4

export PATH=/Soft/cuda/12.0.1/bin:$PATH
#$ -N ProdMbyM 

./kernel00.exe  640 Y
#./kernel00.exe  641 Y
#./kernel01.exe 639 641 1023 Y
#./kernel10.exe 640 512 1024 Y
#./kernel10.exe 639 641 1023 Y
#./kernel11.exe 640 512 1024 Y
#./kernel11.exe 639 641 1023 Y


#ncu --set full ./kernel01.exe 2048 2048 2048 N


