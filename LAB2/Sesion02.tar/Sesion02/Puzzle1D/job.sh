#!/bin/bash

### Directivas para el gestor de colas
#SBATCH --job-name=PUZZLE1D
#SBATCH -D .
#SBATCH --output=submit-PUZZLE1D.o%j
#SBATCH --error=submit-PUZZLE1D.e%j
#SBATCH -A cuda
#SBATCH -p cuda
#SBATCH --gres=gpu:4

export PATH=/Soft/cuda/12.0.1/bin:$PATH


./puzzle1D.exe 30000 Y


./puzzle1D.exe 300000 N



#nsys nvprof --print-gpu-summary ./puzzle1D.exe 30000 N 

#nsys nvprof --print-gpu-trace ./puzzle1D.exe 30000 N

