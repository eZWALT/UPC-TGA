#!/bin/bash

### Directivas para el gestor de colas
#SBATCH --job-name=PUZZLE2D
#SBATCH -D .
#SBATCH --output=submit-PUZZLE2D.o%j
#SBATCH --error=submit-PUZZLE2D.e%j
#SBATCH -A cuda
#SBATCH -p cuda
#SBATCH --gres=gpu:4

export PATH=/Soft/cuda/12.0.1/bin:$PATH

./puzzle2D.exe 1024 1024 Y

#nsys nvprof --print-gpu-summary ./puzzle2D.exe 1024 1024 Y
#nsys nvprof --print-gpu-trace ./puzzle2D.exe 1024 1024 Y

